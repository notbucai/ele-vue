export default {
    lists: []
};