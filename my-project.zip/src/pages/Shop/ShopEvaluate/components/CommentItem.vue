<template>
    <div class="comment">
        <div class="comment-img">
            <img src="//fuss10.elemecdn.com/b/b0/01aeadecc5f172ec4a4f38919e0e4jpeg.jpeg?imageMogr/format/webp/thumbnail/!60x60r/gravity/Center/crop/60x60/" alt="">
        </div>
        <div class="comment-main">
            <div class="comment-main-auto">
                <div class="comment-main-auto-name">匿名用户</div>
                <div class="comment-main-auto-piont"><img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iMTAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IHgxPSIwJSIgeTE9IjUwJSIgeTI9IjUwJSIgaWQ9ImEiPjxzdG9wIHN0b3AtY29sb3I9IiNGRkRFMDAiIG9mZnNldD0iMCUiLz48c3RvcCBzdG9wLWNvbG9yPSIjRkZCMDAwIiBvZmZzZXQ9IjEwMCUiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cGF0aCBkPSJNNTQuMDE3IDguMDcybC0yLjU1MiAxLjU2MWMtLjQ3Ni4yOTEtLjc1OC4wOTYtLjYyNi0uNDU1bC42OTYtMi45MDktMi4yNzMtMS45NDRjLS40MjQtLjM2Mi0uMzI1LS42OTEuMjM5LS43MzZsMi45ODItLjIzN0w1My42My41ODljLjIxMy0uNTE1LjU1Ny0uNTIzLjc3NCAwbDEuMTQ2IDIuNzYzIDIuOTgyLjIzN2MuNTU2LjA0NC42Ny4zNjguMjQuNzM2bC0yLjI3NCAxLjk0NC42OTYgMi45MWMuMTMuNTQyLS4xNDMuNzUtLjYyNi40NTRsLTIuNTUxLTEuNTZ6bS00OCAwTDMuNDY1IDkuNjMzYy0uNDc2LjI5MS0uNzU4LjA5Ni0uNjI2LS40NTVsLjY5Ni0yLjkwOS0yLjI3My0xLjk0NGMtLjQyNC0uMzYyLS4zMjUtLjY5MS4yMzktLjczNmwyLjk4Mi0uMjM3TDUuNjMuNTg5Yy4yMTMtLjUxNS41NTctLjUyMy43NzQgMEw3LjU1IDMuMzUybDIuOTgyLjIzN2MuNTU2LjA0NC42Ny4zNjguMjQuNzM2TDguNDk3IDYuMjY5bC42OTYgMi45MWMuMTMuNTQyLS4xNDMuNzUtLjYyNi40NTRsLTIuNTUxLTEuNTZ6bTEyIDBsLTIuNTUyIDEuNTYxYy0uNDc2LjI5MS0uNzU4LjA5Ni0uNjI2LS40NTVsLjY5Ni0yLjkwOS0yLjI3My0xLjk0NGMtLjQyNC0uMzYyLS4zMjUtLjY5MS4yMzktLjczNmwyLjk4Mi0uMjM3TDE3LjYzLjU4OWMuMjEzLS41MTUuNTU3LS41MjMuNzc0IDBsMS4xNDYgMi43NjMgMi45ODIuMjM3Yy41NTYuMDQ0LjY3LjM2OC4yNC43MzZsLTIuMjc0IDEuOTQ0LjY5NiAyLjkxYy4xMy41NDItLjE0My43NS0uNjI2LjQ1NGwtMi41NTEtMS41NnptMTIgMGwtMi41NTIgMS41NjFjLS40NzYuMjkxLS43NTguMDk2LS42MjYtLjQ1NWwuNjk2LTIuOTA5LTIuMjczLTEuOTQ0Yy0uNDI0LS4zNjItLjMyNS0uNjkxLjIzOS0uNzM2bDIuOTgyLS4yMzdMMjkuNjMuNTg5Yy4yMTMtLjUxNS41NTctLjUyMy43NzQgMGwxLjE0NiAyLjc2MyAyLjk4Mi4yMzdjLjU1Ni4wNDQuNjcuMzY4LjI0LjczNmwtMi4yNzQgMS45NDQuNjk2IDIuOTFjLjEzLjU0Mi0uMTQzLjc1LS42MjYuNDU0bC0yLjU1MS0xLjU2em0xMiAwbC0yLjU1MiAxLjU2MWMtLjQ3Ni4yOTEtLjc1OC4wOTYtLjYyNi0uNDU1bC42OTYtMi45MDktMi4yNzMtMS45NDRjLS40MjQtLjM2Mi0uMzI1LS42OTEuMjM5LS43MzZsMi45ODItLjIzN0w0MS42My41ODljLjIxMy0uNTE1LjU1Ny0uNTIzLjc3NCAwbDEuMTQ2IDIuNzYzIDIuOTgyLjIzN2MuNTU2LjA0NC42Ny4zNjguMjQuNzM2bC0yLjI3NCAxLjk0NC42OTYgMi45MWMuMTMuNTQyLS4xNDMuNzUtLjYyNi40NTRsLTIuNTUxLTEuNTZ6IiBmaWxsPSJ1cmwoI2EpIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=" alt=""></div>
            </div>
            <div class="comment-main-content">
                <div class="comment-main-content-text">这速度真的是杠杠的，味道还不错，鱿鱼再多点点就好了，居然还送了辣条😂</div>
                <div class="comment-main-content-replyy">商家回复：亲爱的顾客，感谢您选择品尝本店的美食，谢谢您认可我们的口味和服务，我们会继续努力，为您提供更好的服务。祝您生活愉快！</div>
                <div class="comment-main-content-img">
                    <ul class="comment-main-content-img-list">
                        <li class="comment-main-content-img-list-item"><img src="//fuss10.elemecdn.com/d/2f/f28e9ae601405e8b61914d1671097jpeg.jpeg?imageMogr/format/webp/thumbnail/300x/" alt=""></li>
                        <li class="comment-main-content-img-list-item"><img src="//fuss10.elemecdn.com/5/e8/4afdd9c1dc534246efe23d8cf23e6jpeg.jpeg?imageMogr/format/webp/thumbnail/300x/" alt=""></li>
                        <li class="comment-main-content-img-list-item"><img src="//fuss10.elemecdn.com/5/e8/4afdd9c1dc534246efe23d8cf23e6jpeg.jpeg?imageMogr/format/webp/thumbnail/300x/" alt=""></li>
                        <li class="comment-main-content-img-list-item"><img src="//fuss10.elemecdn.com/5/e8/4afdd9c1dc534246efe23d8cf23e6jpeg.jpeg?imageMogr/format/webp/thumbnail/300x/" alt=""></li>
                    </ul>
                </div>
            </div>
            <div class="comment-main-source">
                <i class="iconfont icon-good comment-main-source-praise"></i>
                <span class="comment-main-source-name">香辣鱼片1</span>
                <span class="comment-main-source-name">火腿肠炒饭+热狗+鸡排</span>
                <span class="comment-main-source-name">火腿肠炒饭+热狗+鸡排</span>
                <span class="comment-main-source-name">煎荷包蛋</span>
                <span class="comment-main-source-name">香芋地瓜丸</span>
                <span class="comment-main-source-name">川香鸡柳</span>
                <span class="comment-main-source-name">火腿肠</span>
                <span class="comment-main-source-name">美味春卷</span>
            </div>
        </div>
    </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  props: {},
  components: {}
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
.comment {
  //   display: flex;
  position: relative;
  padding: 10px 0;
  &-img {
    width: 32px;
    height: 32px;
    position: absolute;
    img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }
  }
  &-main {
    margin-left: 40px;
    &-auto {
      &-name {
        color: #333;
        font-size: 12px;
        line-height: 18px;
      }
      &-piont {
        width: 56px;
        img {
          width: 100%;
          height: 100%;
        }
        //TODO
      }
    }
    &-content {
      margin-top: 10px;
      &-text {
        color: #444;
        font-size: 12px;
        line-height: 16px;
      }
      &-replyy {
        font-size: 12px;
        line-height: 16px;
        position: relative;
        margin-top: 14px;
        padding: 8px;
        color: #444;
        background-color: #f4f4f4;
        &::before {
          content: "";
          position: absolute;
          top: -20px;
          left: 20px;
          height: 0;
          width: 0;
          border: 10px solid transparent;
          border-bottom-color: #f4f4f4;
        }
      }
      &-img {
        margin-top: 8px;
        &-list {
          display: flex;
          flex-wrap: wrap;
          &-item {
            max-width: 50%;
            padding: 2px;
            box-sizing: border-box;
            img {
              width: 100%;
            }
          }
        }
      }
    }

    &-source {
      display: flex;
      flex-wrap: wrap;
      &-praise {
        font-size: 15px;
        color: #444;
        margin-top: 5px;
        margin-right: 4px;
      }
      &-name {
        font-size: 12px;
        padding:4px;
        margin: 2px;
        border-radius: 2px;
        color: #6d7885;
        background-color: #ebf5ff;
      }
    }
  }
}
</style>
